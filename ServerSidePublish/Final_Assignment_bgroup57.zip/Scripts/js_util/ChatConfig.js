// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
    apiKey: "AIzaSyDH8FhyR_OgX-drG9t4AP2xqT_qPBRLjL0",
    authDomain: "server-side-final-project.firebaseapp.com",
    databaseURL: "https://server-side-final-project-default-rtdb.europe-west1.firebasedatabase.app/",
    projectId: "server-side-final-project",
    storageBucket: "server-side-final-project.appspot.com",
    messagingSenderId: "210522479837",
    appId: "1:210522479837:web:a8aeb1fb9eac16f8108f34",
    measurementId: "G-JRY7CD1KLT"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();